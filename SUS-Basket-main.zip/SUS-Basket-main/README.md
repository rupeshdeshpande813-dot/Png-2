# SUS Ball

My Basketball Game is a 2D 1v1 basketball game developed by a team of 6 people.

## Installation

To install My Basketball Game, download the game files and extract them to a directory on your computer. Make sure to keep all the files in the same directory, as the game needs access to the sound effects and images.

To run the game, navigate to the game directory and run the main game file.

## How to Play

In SUS Ball, you play 1v1 basketball against an opponent. Use the arrow keys to move your player and the down arrow to shoot or steal the ball. the second player play with SQSD.

## Credits

My Basketball Game was developed by:
- Thomas Chometon
- Erwan Maréchal
- Pablo Fereira
- Giorgio
- Arthur Cuoc
- David khersis

## License

SUS Ball is released under the MIT license.